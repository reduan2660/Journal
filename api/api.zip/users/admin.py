from django.contrib import admin
from .models import BlogUser

admin.site.register(BlogUser)